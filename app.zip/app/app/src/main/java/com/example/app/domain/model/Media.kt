package com.example.app.domain.model

data class Media(
    val type: String,
    val url: String
)