package com.example.app.network.dto.comment.request

data class CommentRequest(
    val content: String
)