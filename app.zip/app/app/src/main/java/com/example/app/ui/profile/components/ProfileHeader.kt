package com.example.app.ui.profile.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.app.domain.model.Profile
import androidx.compose.ui.text.style.TextOverflow


@Composable
fun ProfileHeader(
    onBack:()->Unit,
    profile: Profile,
    onFollowerClick: (String) -> Unit,
    onFollowingClick: (String) -> Unit,
    onFollowClick: () -> Unit,
    onUnfollowClick: () -> Unit,
    onUpdateProfileClick:(Profile)->Unit
) {
    val bg = Color(0xFF1F1F1F)
    val textMain = Color.White
    val primaryBlue = Color(0xFF3897F0)
    val grayButton = Color(0xFF3A3A3A)
    val borderColor = Color.White.copy(alpha = 0.5f)



    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = profile.avatarUrl ?: "https://i.pravatar.cc/150?u=${profile.id}",
                contentDescription = null,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, textMain.copy(alpha = 0.2f), CircleShape),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = profile.fullName,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = textMain
            )

            Text(
                text = "@${profile.username}",
                fontSize = 12.sp,
                color = textMain.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProfileStatItem(
                    count = profile.followerCount.toString(),
                    label = "người theo dõi",
                    modifier = Modifier.weight(1f),
                    onClick = { onFollowerClick(profile.id) }
                )
                ProfileStatItem(
                    count = profile.followingCount.toString(),
                    label = "đang theo dõi",
                    modifier = Modifier.weight(1f),
                    onClick = { onFollowingClick(profile.id) }
                )
            }
        }

        }

        Spacer(modifier = Modifier.height(16.dp))


        if (profile.isOwner) {

            OutlinedButton(

                onClick = { onUpdateProfileClick(profile) },

                modifier = Modifier.fillMaxWidth(),

                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White
                ),
                border = BorderStroke(1.dp, borderColor)
            ) {
                Text("Chỉnh sửa hồ sơ", fontWeight = FontWeight.Medium)
            }

        } else {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                Button(
                    onClick = {
                        if (profile.isFollowing) {
                            onUnfollowClick()
                        } else {
                            onFollowClick()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (profile.isFollowing) grayButton else primaryBlue,
                        contentColor = Color.White
                    )
                ) {
                    if (profile.isFollowing) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Đang theo dõi", fontWeight = FontWeight.Medium)
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Theo dõi", fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }

@Composable
private fun ProfileStatItem(
    count: String,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp), // ✅ cân hơn khi đặt cạnh avatar
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = count,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.7f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}