package com.example.app.network.dto.auth.request

data class LoginRequest(
    val email: String,
    val password: String
)