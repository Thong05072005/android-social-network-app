package com.example.app.network.dto.auth.request

data class SendOtpResetPasswordRequest(
    val email: String
)
