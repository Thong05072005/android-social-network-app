package com.example.app.network.dto.auth.request

data class LogoutRequest(
    val refresh_token: String
)