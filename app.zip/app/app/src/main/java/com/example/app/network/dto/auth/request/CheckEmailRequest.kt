package com.example.app.network.dto.auth.request

// CheckEmailRequest.kt
data class CheckEmailRequest(
    val email: String
)
