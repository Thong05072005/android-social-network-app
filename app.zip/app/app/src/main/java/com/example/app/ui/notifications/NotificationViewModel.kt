package com.example.app.ui.notifications

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.app.data.repository.NotificationRepository
import com.example.app.domain.model.Notification
import com.example.app.domain.model.AppNotification
import com.example.app.domain.model.NotificationType
import com.example.app.network.SocketManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONObject

class NotificationViewModel : ViewModel() {
    private val repository = NotificationRepository()

    private val _allNotifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val allNotifications = _allNotifications.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading = _loading.asStateFlow()


    private val _unreadCount = MutableStateFlow(0)


    private val _error = MutableSharedFlow<String>()
    val error = _error.asSharedFlow()

    init {
        observeSocketNotifications()
        fetchNotifications()
        fetchUnreadCount()
    }

    fun fetchNotifications() {
        viewModelScope.launch {
            _loading.value = true

            val result = repository.getNotifications(cursor = null, limit = 20)

            result.onSuccess { domainList ->

                val uiList = domainList.map { mapDomainToAppNotification(it) }
                _allNotifications.value = uiList
            }.onFailure { exception ->
                _error.emit(exception.message ?: "Lỗi tải thông báo")
            }
            _loading.value = false
        }
    }


    fun markAsRead(id: String) {
        viewModelScope.launch {

            _allNotifications.update { list ->
                list.map { if (it.id == id) it.copy(isRead = true) else it }
            }

            if (_unreadCount.value > 0) {
                _unreadCount.value -= 1
            }


            val result = repository.markAsRead(id)

            result.onFailure { e ->

                Log.e("NotiViewModel", "Mark read failed: ${e.message}")
            }
        }
    }

    fun fetchUnreadCount() {
        viewModelScope.launch {
            val result = repository.getUnreadCount()

            result.onSuccess { count ->
                _unreadCount.value = count
            }.onFailure {
                Log.e("NotiViewModel", "Get unread count failed")
            }
        }
    }

    private fun mapDomainToAppNotification(domain: Notification): AppNotification {
        val typeEnum = when (domain.type) {
            "like_post" -> NotificationType.LIKE_POST
            "comment_post" -> NotificationType.COMMENT_POST
            "share_post" -> NotificationType.SHARE_POST
            "follow" -> NotificationType.FOLLOW
            else -> NotificationType.SHARE_POST
        }

        return AppNotification(
            id = domain.id,
            type = typeEnum,
            actorName = domain.users.username,
            message = domain.content,
            timeText = domain.createdAt,
            isRead = domain.isRead,
            actorId = domain.users.id,
            postId = domain.targetId,
            avatarUrl = domain.users.avatar
        )
    }

    private fun observeSocketNotifications() {
        viewModelScope.launch {
            SocketManager.notificationFlow.collect { json ->
                val newNotif = mapJsonToNotification(json)
                _allNotifications.update { currentList ->
                    listOf(newNotif) + currentList
                }
                _unreadCount.value += 1
            }
        }
    }

    private fun mapJsonToNotification(json: JSONObject): AppNotification {
        val rawType = json.optString("type", "").lowercase()
        val notificationType = when (rawType) {
            "like_post"      -> NotificationType.LIKE_POST
            "like_comment"   -> NotificationType.LIKE_COMMENT
            "comment_post"   -> NotificationType.COMMENT_POST
            "reply_comment"  -> NotificationType.REPLY_COMMENT
            "follow"         -> NotificationType.FOLLOW
            "share_post"     -> NotificationType.SHARE_POST
            else             -> NotificationType.SHARE_POST
        }

        return AppNotification(
            id = json.optString("id", System.currentTimeMillis().toString()),
            type = notificationType,
            actorName = "Ai đó",
            message = json.optString("content", "đã tương tác với bạn"),
            timeText = "Vừa xong",
            isRead = json.optBoolean("is_read", false),
            actorId = json.optString("actor_id"),
            postId = json.optString("target_id"),
            avatarUrl = null
        )
    }
}